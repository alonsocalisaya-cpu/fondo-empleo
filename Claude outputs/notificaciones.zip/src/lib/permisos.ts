/**
 * Permisos por rol. Este archivo no accede a la base de datos: lo usan el proxy, las páginas,
 * el menú y las acciones para decidir qué puede ver (ver) y modificar (editar) cada rol.
 */
import type { RolUsuario } from "@/db/schema";
import type { RolFlujo } from "./flujo-pre";

export const ROLES_USUARIO: Record<RolUsuario, string> = {
  admin: "Administrador del sistema",
  jefe_proyecto: "Jefe de Proyecto",
  jefe_comercial: "Jefe Comercial",
  asistente: "Asistente de Capacitación",
  capacitador: "Capacitador (consultor)",
  gestion_documental: "Encargado de Gestión Documental",
  administradora: "Administradora",
  rrhh: "Recursos Humanos",
};

export type Modulo =
  | "inicio"
  | "calendario"
  | "cronograma"
  | "consultores"
  | "indicadores"
  | "acciones"
  | "capacitaciones"
  | "beneficiarios"
  | "rrhh"
  | "logistica"
  | "mantenimiento"
  | "documental"
  | "usuarios";

export type Nivel = "ver" | "editar";

export const MODULOS: Record<Modulo, { nombre: string; rutas: string[] }> = {
  inicio: { nombre: "Inicio", rutas: ["/"] },
  calendario: { nombre: "Calendario", rutas: ["/calendario"] },
  cronograma: { nombre: "Cronograma y estructura", rutas: ["/estrategico/cronograma"] },
  consultores: { nombre: "Asignación de consultores", rutas: ["/estrategico/consultores"] },
  indicadores: { nombre: "Indicadores", rutas: ["/estrategico/indicadores", "/estrategico"] },
  acciones: { nombre: "Acciones correctivas", rutas: ["/estrategico/acciones-correctivas"] },
  beneficiarios: { nombre: "Beneficiarios", rutas: ["/operativo/capacitaciones/participantes"] },
  capacitaciones: { nombre: "Capacitaciones (pre y post, asistencia)", rutas: ["/operativo"] },
  rrhh: { nombre: "Recursos humanos", rutas: ["/soporte/recursos-humanos"] },
  logistica: { nombre: "Logística (inventario y sedes)", rutas: ["/soporte/logistica"] },
  mantenimiento: { nombre: "Mantenimiento (equipos)", rutas: ["/soporte/mantenimiento"] },
  documental: { nombre: "Gestión documental", rutas: ["/soporte/gestion-documental"] },
  usuarios: { nombre: "Usuarios y roles", rutas: ["/usuarios"] },
};

const V: Nivel = "ver";
const E: Nivel = "editar";

/** Tabla de permisos: lo que no aparece, no se puede ni ver. */
export const PERMISOS: Record<RolUsuario, Partial<Record<Modulo, Nivel>>> = {
  admin: Object.fromEntries((Object.keys(MODULOS) as Modulo[]).map((m) => [m, E])),
  jefe_proyecto: {
    inicio: V, calendario: V, cronograma: E, consultores: E, indicadores: V, acciones: E,
    capacitaciones: E, beneficiarios: E, rrhh: V, logistica: E, mantenimiento: E, documental: E,
  },
  jefe_comercial: { inicio: V, calendario: V, cronograma: V, indicadores: V, capacitaciones: E, logistica: V },
  asistente: {
    inicio: V, calendario: V, cronograma: V, capacitaciones: E, beneficiarios: E, logistica: E, mantenimiento: E, documental: V,
  },
  capacitador: { calendario: V, capacitaciones: E },
  gestion_documental: {
    inicio: V, calendario: V, cronograma: V, capacitaciones: E, beneficiarios: V, logistica: V, mantenimiento: V, documental: E,
  },
  administradora: { inicio: V, calendario: V, indicadores: V, capacitaciones: E, logistica: E, mantenimiento: V, rrhh: V },
  rrhh: { inicio: V, calendario: V, cronograma: V, consultores: E, capacitaciones: V, beneficiarios: V, rrhh: E },
};

/** Módulo al que pertenece una ruta (el de la ruta más específica que coincida). */
export function moduloDe(ruta: string): Modulo | null {
  let mejor: { m: Modulo; largo: number } | null = null;
  for (const [m, def] of Object.entries(MODULOS) as [Modulo, (typeof MODULOS)[Modulo]][]) {
    for (const r of def.rutas) {
      const coincide = r === "/" ? ruta === "/" : ruta === r || ruta.startsWith(`${r}/`);
      if (coincide && (!mejor || r.length > mejor.largo)) mejor = { m, largo: r.length };
    }
  }
  return mejor?.m ?? null;
}

export function nivel(rol: RolUsuario, modulo: Modulo): Nivel | null {
  return PERMISOS[rol][modulo] ?? null;
}

export function puede(rol: RolUsuario, modulo: Modulo, requerido: Nivel = "ver") {
  const n = nivel(rol, modulo);
  return n === "editar" || (n === "ver" && requerido === "ver");
}

/** Rutas que cualquier usuario con sesión puede abrir. */
export const RUTAS_LIBRES = ["/cuenta", "/sin-permiso", "/archivos", "/notificaciones", "/api/notificaciones"];

export function puedeAbrir(rol: RolUsuario, ruta: string) {
  if (RUTAS_LIBRES.some((r) => ruta === r || ruta.startsWith(`${r}/`))) return true;
  const m = moduloDe(ruta);
  return m === null ? rol === "admin" : puede(rol, m, "ver");
}

/** Página de inicio según el rol (el capacitador va directo a sus sesiones). */
export function inicioDe(rol: RolUsuario) {
  return puede(rol, "inicio") ? "/" : "/operativo/capacitaciones";
}

/** ¿Este usuario puede registrar una actividad del flujo que corresponde a estos roles? */
export function puedeRegistrarPaso(rol: RolUsuario, rolesPaso: RolFlujo[]) {
  return rol === "admin" || (rolesPaso as string[]).includes(rol);
}

/** Quiénes arman la 1ra sección de la ficha (ítems, refrigerio y equipos). */
export const ROLES_FICHA: RolUsuario[] = ["admin", "jefe_proyecto", "asistente"];
export const puedeEditarFicha = (rol: RolUsuario) => ROLES_FICHA.includes(rol);
