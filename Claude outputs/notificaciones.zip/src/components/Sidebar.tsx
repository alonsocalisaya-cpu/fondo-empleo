"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { AREAS, type Area } from "@/lib/navegacion";
import Campana from "./Campana";

// Íconos simples de trazo para cada área
const ICONOS: Record<Area["id"], React.ReactNode> = {
  estrategico: <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" strokeLinecap="round" strokeLinejoin="round" />,
  operativo: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" strokeLinecap="round" />
    </>
  ),
  soporte: <path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.5-.5-.5-2.5z" strokeLinejoin="round" />,
};

/** ¿La ruta pertenece a algún módulo que el rol puede abrir? */
const permitida = (href: string, rutas: string[]) => rutas.some((r) => (r === "/" ? href === "/" : href === r || href.startsWith(`${r}/`)));

export default function Sidebar({
  usuario,
  rutasPermitidas,
  cerrarSesion,
}: {
  usuario: { nombre: string; rol: string };
  rutasPermitidas: string[];
  cerrarSesion: () => Promise<void>;
}) {
  const path = usePathname();
  const areas = AREAS.map((a) => ({ ...a, bloques: a.bloques.filter((b) => permitida(b.href, rutasPermitidas)) })).filter((a) => a.bloques.length);
  const areaActiva = areas.find((a) => path.startsWith(`/${a.id}`))?.id;
  const [abiertas, setAbiertas] = useState<Set<string>>(() => new Set(areaActiva ? [areaActiva] : []));

  // Al navegar a otra área (por un enlace), se abre automáticamente
  const [ultimaArea, setUltimaArea] = useState(areaActiva);
  if (areaActiva !== ultimaArea) {
    setUltimaArea(areaActiva);
    if (areaActiva && !abiertas.has(areaActiva)) setAbiertas(new Set([...abiertas, areaActiva]));
  }

  const alternar = (id: string) =>
    setAbiertas((prev) => {
      const s = new Set(prev);
      if (s.has(id)) s.delete(id);
      else s.add(id);
      return s;
    });

  return (
    <nav
      aria-label="Principal"
      className="sticky top-0 flex h-screen w-66 shrink-0 flex-col gap-1 overflow-y-auto bg-marino px-4 py-6 print:hidden"
    >
      <div className="mb-6 flex items-center gap-1">
        <Link href="/" className="flex flex-1 items-center gap-3 rounded-lg px-2 py-1 hover:bg-marino-3">
          <div className="flex size-10 items-center justify-center rounded-[10px] bg-acento font-bold text-white">GC</div>
          <div className="flex flex-col leading-tight">
            <span className="text-[15px] font-semibold text-white">Gestión de</span>
            <span className="text-[13px] text-niebla">Capacitaciones</span>
          </div>
        </Link>
        <Campana />
      </div>

      {[
        {
          href: "/calendario",
          label: "Calendario",
          icono: (
            <>
              <rect x="3" y="5" width="18" height="16" rx="2" />
              <path d="M3 10h18M8 3v4M16 3v4" strokeLinecap="round" />
            </>
          ),
        },
        {
          href: "/usuarios",
          label: "Usuarios y roles",
          icono: (
            <>
              <circle cx="9" cy="8" r="3.5" />
              <path d="M2.5 20c.8-3.6 3.3-5.5 6.5-5.5s5.7 1.9 6.5 5.5M16 4.8a3.5 3.5 0 0 1 0 6.4M18.5 14.8c1.6.8 2.6 2.5 3 5.2" strokeLinecap="round" />
            </>
          ),
        },
      ]
        .filter((i) => permitida(i.href, rutasPermitidas))
        .map((i) => {
          const activo = path.startsWith(i.href);
          return (
            <Link
              key={i.href}
              href={i.href}
              aria-current={activo ? "page" : undefined}
              className={`flex items-center gap-3 rounded-lg px-3.5 py-3 text-[15px] transition-colors ${
                activo ? "bg-marino-2 font-semibold text-white" : "text-niebla hover:bg-marino-3 hover:text-white"
              }`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="size-5 shrink-0" aria-hidden="true">
                {i.icono}
              </svg>
              {i.label}
            </Link>
          );
        })}

      {areas.map((area) => {
        const abierta = abiertas.has(area.id);
        const activa = area.id === areaActiva;
        return (
          <div key={area.id} className="flex flex-col">
            <button
              type="button"
              onClick={() => alternar(area.id)}
              aria-expanded={abierta}
              aria-controls={`menu-${area.id}`}
              className={`flex items-center gap-3 rounded-lg px-3.5 py-3 text-left text-[15px] transition-colors ${
                activa ? "font-semibold text-white" : "text-niebla hover:bg-marino-3 hover:text-white"
              }`}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="size-5 shrink-0" aria-hidden="true">
                {ICONOS[area.id]}
              </svg>
              <span className="flex-1">{area.label}</span>
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className={`size-4 transition-transform ${abierta ? "rotate-90" : ""}`}
                aria-hidden="true"
              >
                <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <ul id={`menu-${area.id}`} hidden={!abierta} className="mb-2 ml-[22px] flex flex-col gap-0.5 border-l border-marino-3 pl-3">
              {area.bloques.map((b) => {
                const actual = [b.href, ...(b.tambien ?? [])].some((h) => path === h || path.startsWith(`${h}/`));
                return (
                  <li key={b.href}>
                    <Link
                      href={b.href}
                      aria-current={actual ? "page" : undefined}
                      className={`block rounded-md px-3 py-2.5 text-sm transition-colors ${
                        actual ? "bg-marino-2 font-semibold text-white" : "text-niebla hover:bg-marino-3 hover:text-white"
                      }`}
                    >
                      {b.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}

      <div className="flex-1" />
      <div className="flex flex-col gap-2 border-t border-marino-3 px-2 pt-3">
        <div className="flex items-center gap-3">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#f6d9c7] text-sm font-semibold text-[#7c2d12]">
            {usuario.nombre.split(" ").filter(Boolean).slice(0, 2).map((x) => x[0]).join("").toUpperCase()}
          </div>
          <div className="flex min-w-0 flex-col leading-tight">
            <span className="truncate text-sm font-medium text-white">{usuario.nombre}</span>
            <span className="truncate text-xs text-niebla">{usuario.rol}</span>
          </div>
        </div>
        <div className="flex gap-2 text-xs">
          <Link href="/cuenta" className="rounded px-2 py-1 text-niebla hover:bg-marino-3 hover:text-white">Mi cuenta</Link>
          <form action={cerrarSesion}>
            <button className="rounded px-2 py-1 text-niebla hover:bg-marino-3 hover:text-white">Salir</button>
          </form>
        </div>
      </div>
    </nav>
  );
}
