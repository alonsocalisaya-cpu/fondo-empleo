import { usuarioActual } from "@/lib/auth";
import { marcarVistas, notificacionesDe } from "@/lib/notificaciones";

/** Lo que muestra la campana: las actividades pendientes del usuario (las primeras 30) y cuántas son nuevas. */
export async function GET() {
  const u = await usuarioActual();
  if (!u) return Response.json({ error: "Sin sesión" }, { status: 401 });
  const todas = await notificacionesDe(u);
  return Response.json({ total: todas.length, nuevas: todas.filter((n) => n.nueva).length, items: todas.slice(0, 30) });
}

/** Al abrir la campana: todo lo actual deja de ser «nuevo». */
export async function POST() {
  const u = await usuarioActual();
  if (!u) return Response.json({ error: "Sin sesión" }, { status: 401 });
  await marcarVistas(u.id);
  return Response.json({ ok: true });
}
