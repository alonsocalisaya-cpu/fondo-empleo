import type { NextConfig } from "next";
import { networkInterfaces } from "node:os";

// IPs de este equipo en la red local (para abrir la app desde otros equipos: http://<IP>:4000)
const ipsLocales = Object.values(networkInterfaces())
  .flat()
  .filter((i) => i && i.family === "IPv4" && !i.internal)
  .map((i) => i!.address);

const nextConfig: NextConfig = {
  // En modo desarrollo, Next.js solo acepta "localhost"; así también acepta la IP del equipo.
  allowedDevOrigins: ipsLocales,

  // Direcciones antiguas (antes del menú Estratégico / Operativo / Soporte)
  async redirects() {
    return [
      { source: "/capacitaciones", destination: "/estrategico/cronograma/estructura", permanent: false },
      { source: "/programacion", destination: "/estrategico/cronograma", permanent: false },
      { source: "/programacion/:ruta*", destination: "/estrategico/cronograma/:ruta*", permanent: false },
      { source: "/asistencia", destination: "/operativo/capacitacion", permanent: false },
      { source: "/asistencia/:ruta*", destination: "/operativo/capacitacion/:ruta*", permanent: false },
      { source: "/participantes", destination: "/operativo/pre-capacitacion/participantes", permanent: false },
      { source: "/capacitadores", destination: "/soporte/recursos-humanos", permanent: false },
      { source: "/sedes", destination: "/soporte/logistica/sedes", permanent: false },
    ];
  },
};

export default nextConfig;
