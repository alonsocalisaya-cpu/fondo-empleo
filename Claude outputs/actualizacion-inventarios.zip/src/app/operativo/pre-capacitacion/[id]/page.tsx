import Link from "next/link";
import { TIPOS_EQUIPO } from "@/lib/inventario";
import { notFound } from "next/navigation";
import { connection } from "next/server";
import type { PasoRegistro } from "@/db/schema";
import { cargarExpediente } from "@/lib/preparacion";
import { ruta, combinadas } from "@/lib/consultas";
import { FASES, PASO, resumenFlujo, DIAS_ANTICIPACION_COMUNICACION, type RolFlujo } from "@/lib/flujo-pre";
import { fechaCorta, fechaLarga, hora, sumarDias, hoyISO } from "@/lib/fechas";
import { ChipEstado, Encabezado, nombreCompleto } from "@/components/ui";
import { BarraAvance, ChipRol } from "@/components/flujo";
import FormPaso, { BotonesDecision, FormItem } from "./FormPaso";
import { alternarItem, deshacerPaso, eliminarItem } from "./actions";

export const metadata = { title: "Expediente de pre-capacitación" };

type Exp = NonNullable<Awaited<ReturnType<typeof cargarExpediente>>>;
type EstadoItem = ReturnType<typeof resumenFlujo>["estados"][number];

const CATEGORIAS = {
  material_capacitador: "Material solicitado por el capacitador",
  dinamica: "Material para dinámicas",
  refrigerio: "Insumos de refrigerio",
  tecnologico: "Equipos tecnológicos",
} as const;

const EXAMEN = { entrada: "de entrada", salida: "de salida", ambos: "de entrada y de salida" } as const;
const fechaHora = (iso: string) =>
  new Intl.DateTimeFormat("es-PE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "America/Lima" }).format(new Date(iso));

/* ── Personas que pueden registrar cada rol ─────────────── */
function personasDe(rol: RolFlujo, e: Exp) {
  if (rol === "capacitador") {
    const lista = e.p.capacitador ? [e.p.capacitador] : e.consultores;
    return lista.map((c) => ({ valor: `c${c.id}`, nombre: nombreCompleto(c) }));
  }
  if (rol === "asistente" && e.p.asistente) return [{ valor: `p${e.p.asistente.id}`, nombre: nombreCompleto(e.p.asistente) }];
  return e.personal.filter((x) => x.rol === rol).map((x) => ({ valor: `p${x.id}`, nombre: nombreCompleto(x) }));
}

/* ── Resumen de lo registrado ────────────────────────────── */
function Resumen({ clave, r }: { clave: string; r: PasoRegistro }) {
  const d = r as Record<string, unknown>;
  const partes: string[] = [];
  switch (clave) {
    case "confirmar_sede":
      partes.push(d.localConfirmado ? "Local confirmado" : "Local NO confirmado → reprogramar");
      if (d.contacto) partes.push(`Contacto: ${d.contacto}`);
      break;
    case "asignar_personal":
      partes.push(`Capacitador: ${d.capacitador}`, `Asistente: ${d.asistente}`);
      break;
    case "comunicar":
      partes.push(d.aTiempo ? "Comunicado a tiempo" : `Comunicado fuera de plazo (límite ${fechaCorta(String(d.limite))})`);
      break;
    case "personalizar":
      partes.push(d.personalizado ? `Personalizado: ${d.detalle}` : "Sin personalizar");
      break;
    case "dinamicas":
      partes.push(
        d.requiere
          ? d.delInventario !== undefined
            ? `Solicitó ${d.delInventario} ítem(s) del inventario y ${d.extras} extra(s)`
            : `Solicitó ${d.items} ítem(s) al asistente`
          : "No requiere material",
      );
      break;
    case "examen":
      partes.push(`Examen ${EXAMEN[d.tipo as keyof typeof EXAMEN] ?? ""} impreso${d.cantidad ? ` (${d.cantidad})` : ""}`);
      break;
    case "guardar_material":
      partes.push(`Medio: ${d.medio}`, d.talleresImpresos ? "Talleres impresos" : "Talleres sin imprimir");
      break;
    case "coordinar_salida_cap":
    case "coordinar_salida_asis":
      partes.push(`Salida ${d.horaSalida}${d.punto ? ` · ${d.punto}` : ""}`);
      break;
    case "probar_equipos":
      partes.push(d.resultado === "observado" ? "Con observaciones" : "Todo operativo");
      break;
    case "solicitar_viaticos":
    case "entregar_viaticos":
      partes.push(`S/ ${Number(d.monto).toFixed(2)}${d.tipo ? ` · ${d.tipo === "viaje" ? "viaje" : "movilidad"}` : ""}${d.concepto ? ` · ${d.concepto}` : ""}`);
      break;
    case "revisar_ficha":
      partes.push("Ficha correcta");
      break;
  }
  if (d.obs) partes.push(`Obs.: ${d.obs}`);
  return (
    <p className="text-[13px] text-[#166534]">
      {partes.join(" · ")}
      <span className="block text-xs text-texto-2">
        {fechaHora(r.en)}{r.por ? ` · ${r.por}` : ""}
      </span>
    </p>
  );
}

/* ── Campos del formulario de cada actividad ─────────────── */
function Campos({ clave, e }: { clave: string; e: Exp }) {
  const pasos = e.ctx.pasos;
  switch (clave) {
    case "confirmar_local":
      return <input name="obs" placeholder="Observación (opcional)" aria-label="Observación" className="campo py-2" />;
    case "confirmar_sede":
      return (
        <>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <input name="contacto" defaultValue={e.p.sede.contacto ?? ""} placeholder="Persona de contacto en la sede" aria-label="Contacto en la sede" className="campo py-2" />
            <input name="obs" placeholder="Observación (obligatoria si NO se confirma)" aria-label="Observación" className="campo py-2" />
          </div>
          <p className="text-[13px] font-semibold text-marino">¿Local confirmado?</p>
          <BotonesDecision si="Sí, confirmado" no="No, reprogramar" />
        </>
      );
    case "asignar_personal": {
      // Solo se ofrecen personas SIN cruce de horario ese día
      const caps = e.consultores.filter((c) => !e.ocupadosCap.has(c.id));
      const asistentes = e.personal.filter((x) => x.rol === "asistente");
      const asisLibres = asistentes.filter((a) => !e.ocupadosAsis.has(a.id));
      const noDisp = [
        ...e.consultores.filter((c) => e.ocupadosCap.has(c.id)).map((c) => `${nombreCompleto(c)} (${e.ocupadosCap.get(c.id)})`),
        ...asistentes.filter((a) => e.ocupadosAsis.has(a.id)).map((a) => `${nombreCompleto(a)} (${e.ocupadosAsis.get(a.id)})`),
      ];
      return (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          <div>
            <label htmlFor="f-cap" className="etiqueta">Capacitador disponible ({caps.length})</label>
            <select id="f-cap" name="capacitadorId" defaultValue={caps.some((c) => c.id === e.p.capacitadorId) ? e.p.capacitadorId! : ""} className="campo py-2">
              <option value="">{caps.length ? "Elegir…" : "Ninguno disponible en este horario"}</option>
              {caps.map((c) => <option key={c.id} value={c.id}>{nombreCompleto(c)}{c.especialidad ? ` — ${c.especialidad}` : ""}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="f-asi" className="etiqueta">Asistente disponible ({asisLibres.length})</label>
            <select id="f-asi" name="asistenteId" defaultValue={asisLibres.some((a) => a.id === e.p.asistenteId) ? e.p.asistenteId! : ""} className="campo py-2">
              <option value="">{asisLibres.length ? "Elegir…" : "Ninguno disponible en este horario"}</option>
              {asisLibres.map((a) => <option key={a.id} value={a.id}>{nombreCompleto(a)}</option>)}
            </select>
          </div>
          <p className="text-xs text-texto-2 sm:col-span-2">
            Solo se muestran las personas sin otra sesión que se cruce el {fechaCorta(e.p.fecha)} de {hora(e.p.horaInicio)} a {hora(e.p.horaFin)}.
            {asistentes.length === 0 && " No hay asistentes registrados: agrégalos en Soporte › Recursos humanos."}
          </p>
          {noDisp.length > 0 && (
            <details className="text-xs text-texto-2 sm:col-span-2">
              <summary className="cursor-pointer">No disponibles por cruce de horario ({noDisp.length})</summary>
              <ul className="mt-1 list-disc pl-5">{noDisp.map((n) => <li key={n}>{n}</li>)}</ul>
            </details>
          )}
          {(caps.length === 0 || asisLibres.length === 0) && (
            <p role="alert" className="rounded-md bg-[#fef3c7] px-3 py-2 text-[13px] text-[#92400e] sm:col-span-2">
              ¿Hay disponibilidad? <strong>No</strong>: registra más personal en Recursos humanos o cambia el horario en Editar programación.
            </p>
          )}
        </div>
      );
    }
    case "comunicar": {
      const limite = sumarDias(e.p.fecha, -DIAS_ANTICIPACION_COMUNICACION);
      const vencido = hoyISO() > limite;
      return (
        <>
          <p className={`text-[13px] ${vencido ? "font-semibold text-[#991b1b]" : "text-texto-2"}`}>
            Plazo: hasta el {fechaCorta(limite)} ({DIAS_ANTICIPACION_COMUNICACION} días antes).{vencido && " ⚠ Plazo vencido."}
          </p>
          <input name="obs" placeholder="Observación (opcional)" aria-label="Observación" className="campo py-2" />
        </>
      );
    }
    case "descargar_material":
      return e.docs.filter((d) => d.tipo === "diapositiva" || d.tipo === "taller").length === 0 ? (
        <p className="text-[13px] text-[#92400e]">
          Aún no hay diapositivas ni talleres para esta sesión en el repositorio.{" "}
          <Link href={`/soporte/gestion-documental?sesion=${e.p.sesionId}`} className="enlace">Registrarlos en Gestión documental</Link>
        </p>
      ) : (
        <ul className="flex flex-col gap-1 text-[13px]">
          {e.docs.filter((d) => d.tipo === "diapositiva" || d.tipo === "taller").map((d) => (
            <li key={d.id}>
              <a href={d.url} target="_blank" rel="noreferrer" className="enlace">⬇ {d.nombre}</a>
              <span className="text-texto-2"> · {d.tipo}{d.version ? ` v${d.version}` : ""}</span>
            </li>
          ))}
        </ul>
      );
    case "personalizar":
      return (
        <>
          <input name="detalle" placeholder="Si personalizas: ¿qué cambiaste?" aria-label="Detalle de la personalización" className="campo py-2" />
          <p className="text-[13px] font-semibold text-marino">¿Necesitas personalizar el contenido?</p>
          <BotonesDecision si="Sí, lo personalicé" no="No es necesario" />
        </>
      );
    case "dinamicas": {
      const materiales = e.inventario.filter((i) => i.categoria === "material");
      return (
        <>
          <p className="text-[13px] font-semibold text-marino">Del inventario de Logística <span className="font-normal text-texto-2">(se descuenta del stock)</span></p>
          {materiales.length === 0 ? (
            <p className="text-xs text-texto-2">No hay materiales en el inventario. <Link href="/soporte/logistica" className="enlace">Ir a Logística</Link></p>
          ) : (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {materiales.map((i) => (
                <label key={i.id} className={`flex items-center gap-2 rounded-md border px-2 py-1.5 text-[13px] ${i.stock === 0 ? "border-[#fecaca] text-texto-2" : "border-borde"}`}>
                  <input name={`inv-${i.id}`} type="number" min={0} max={i.stock} placeholder="0" disabled={i.stock === 0} aria-label={`Cantidad de ${i.nombre}`} className="campo w-16 px-2 py-1" />
                  <span className="flex flex-col leading-tight">
                    <span>{i.nombre}</span>
                    <span className={`text-[11px] ${i.stock < i.stockMinimo ? "text-[#991b1b]" : "text-texto-2"}`}>stock {i.stock} {i.unidad}</span>
                  </span>
                </label>
              ))}
            </div>
          )}
          <label htmlFor="f-extras" className="text-[13px] font-semibold text-marino">Extras que no están en el inventario</label>
          <textarea
            id="f-extras"
            name="items"
            rows={2}
            placeholder={"Uno por línea con cantidad:\n20 vasos descartables\n10 hojas de colores"}
            className="campo py-2"
          />
          <p className="text-[13px] font-semibold text-marino">¿Requiere material para dinámicas?</p>
          <BotonesDecision si="Sí, solicitar al asistente" no="No requiere" />
        </>
      );
    }
    case "examen": {
      const doc = e.docs.find((d) => d.tipo === (e.ctx.examen === "salida" ? "examen_salida" : "examen_entrada"));
      return (
        <div className="flex flex-wrap items-end gap-3 text-[13px]">
          <p className="w-full">
            Esta es la <strong>{e.ctx.examen === "entrada" ? "primera" : e.ctx.examen === "salida" ? "última" : "única"}</strong> sesión: imprimir examen {EXAMEN[e.ctx.examen ?? "entrada"]}.
            {doc ? <> <a href={doc.url} target="_blank" rel="noreferrer" className="enlace">⬇ {doc.nombre}</a></> : " (No hay examen en el repositorio.)"}
          </p>
          <div className="w-40">
            <label htmlFor="f-cant" className="etiqueta">Copias impresas</label>
            <input id="f-cant" name="cantidad" type="number" min={0} defaultValue={e.inscritos} className="campo py-2" />
          </div>
        </div>
      );
    }
    case "guardar_material":
      return (
        <div className="flex flex-wrap items-center gap-4">
          <div className="w-48">
            <label htmlFor="f-medio" className="etiqueta">Medio seguro</label>
            <select id="f-medio" name="medio" className="campo py-2" defaultValue="USB">
              <option>USB</option><option>Nube</option><option>WhatsApp</option><option>Otro</option>
            </select>
          </div>
          <label className="flex items-center gap-2 pt-5 text-[13px]">
            <input type="checkbox" name="talleresImpresos" defaultChecked className="size-4 accent-marino" /> Talleres impresos
          </label>
        </div>
      );
    case "coordinar_salida_cap":
    case "coordinar_salida_asis": {
      const otro = pasos[clave === "coordinar_salida_cap" ? "coordinar_salida_asis" : "coordinar_salida_cap"] as Record<string, unknown> | undefined;
      return (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[140px_1fr]">
          <div>
            <label htmlFor={`h-${clave}`} className="etiqueta">Hora de salida</label>
            <input id={`h-${clave}`} name="horaSalida" type="time" required defaultValue={(otro?.horaSalida as string) ?? ""} className="campo py-2" />
          </div>
          <div>
            <label htmlFor={`pt-${clave}`} className="etiqueta">Punto de encuentro</label>
            <input id={`pt-${clave}`} name="punto" defaultValue={(otro?.punto as string) ?? ""} placeholder="Ej. Oficina central" className="campo py-2" />
          </div>
        </div>
      );
    }
    case "imprimir_ficha":
      return (
        <div className="flex flex-wrap gap-3 text-[13px]">
          <Link href={`/operativo/pre-capacitacion/${e.p.id}/ficha`} target="_blank" className="enlace">🖨 Ficha de capacitación</Link>
          <Link href={`/operativo/capacitacion/${e.p.id}/imprimir`} target="_blank" className="enlace">🖨 Lista de asistencia</Link>
        </div>
      );
    case "alistar_material": {
      const pend = e.items.filter((i) => !i.listo).length;
      return (
        <p className={`text-[13px] ${pend ? "text-[#92400e]" : "text-[#166534]"}`}>
          {e.items.length === 0
            ? "La ficha no tiene ítems. Agrégalos arriba en «Ficha de capacitación · 1ra sección»."
            : pend
              ? `Faltan ${pend} de ${e.items.length} ítems por marcar como listos (arriba, en la ficha).`
              : `Los ${e.items.length} ítems de la ficha están listos.`}
        </p>
      );
    }
    case "probar_equipos": {
      const malos = e.equipos.filter((q) => q.estado !== "operativo");
      return (
        <>
          {e.equipos.length === 0 ? (
            <p className="text-[13px] text-texto-2">
              No hay equipos registrados para esta sede. <Link href="/soporte/mantenimiento" className="enlace">Registrar en Mantenimiento</Link>
            </p>
          ) : (
            <ul className="grid grid-cols-1 gap-1 text-[13px] sm:grid-cols-2">
              {e.equipos.map((q) => (
                <li key={q.id} className={q.estado === "operativo" ? "" : "font-semibold text-[#991b1b]"}>
                  {q.estado === "operativo" ? "✓" : "✕"} {TIPOS_EQUIPO[q.tipo].singular} · {q.nombre} ({q.codigo}) · {q.sede?.nombre ?? "itinerante"} · {q.estado.replace("_", " ")}
                </li>
              ))}
            </ul>
          )}
          {malos.length > 0 && <p className="text-[13px] text-[#991b1b]">⚠ {malos.length} equipo(s) no están operativos según Mantenimiento.</p>}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-[180px_1fr]">
            <select name="resultado" aria-label="Resultado de la prueba" className="campo py-2" defaultValue="ok">
              <option value="ok">Todo operativo</option>
              <option value="observado">Con observaciones</option>
            </select>
            <input name="obs" placeholder="Observaciones de la prueba" aria-label="Observaciones" className="campo py-2" />
          </div>
        </>
      );
    }
    case "solicitar_viaticos":
      return (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[140px_1fr]">
          <div>
            <label htmlFor="f-monto" className="etiqueta">Monto (S/)</label>
            <input id="f-monto" name="monto" type="number" min={0} step="0.10" required className="campo py-2" />
          </div>
          <div>
            <label htmlFor="f-conc" className="etiqueta">Concepto</label>
            <input id="f-conc" name="concepto" defaultValue={e.p.sede.fueraDeArequipa ? "Pasajes, alimentación y hospedaje" : "Movilidad local"} className="campo py-2" />
          </div>
        </div>
      );
    case "entregar_viaticos": {
      const sol = pasos.solicitar_viaticos as Record<string, unknown> | undefined;
      return (
        <div className="flex flex-wrap items-end gap-3 text-[13px]">
          <p className="w-full">
            Sede {e.p.sede.fueraDeArequipa ? "FUERA" : "dentro"} de Arequipa → viáticos para <strong>{e.p.sede.fueraDeArequipa ? "viaje" : "movilidad"}</strong>. Solicitado: S/ {Number(sol?.monto ?? 0).toFixed(2)}
          </p>
          <div className="w-40">
            <label htmlFor="f-ent" className="etiqueta">Monto entregado (S/)</label>
            <input id="f-ent" name="monto" type="number" min={0} step="0.10" defaultValue={Number(sol?.monto ?? 0) || ""} required className="campo py-2" />
          </div>
        </div>
      );
    }
    case "llenar_ficha": {
      const obs = (pasos.observaciones_ficha?.lista as { obs: string; en: string; por?: string }[] | undefined) ?? [];
      const ultima = obs.at(-1);
      return (
        <>
          {ultima && (
            <p className="rounded-md bg-[#fef3c7] px-3 py-2 text-[13px] text-[#92400e]">
              Observación de Gestión Documental ({fechaHora(ultima.en)}): {ultima.obs}
            </p>
          )}
          <input name="obs" placeholder="Comentario para el encargado (opcional)" aria-label="Comentario" className="campo py-2" />
        </>
      );
    }
    case "revisar_ficha":
      return (
        <>
          <p className="text-[13px]">
            <Link href={`/operativo/pre-capacitacion/${e.p.id}/ficha`} target="_blank" className="enlace">Ver ficha</Link> · {e.items.length} ítems en la 1ra sección
          </p>
          <input name="obs" placeholder="Observaciones (obligatorias si NO está correcta)" aria-label="Observaciones" className="campo py-2" />
          <p className="text-[13px] font-semibold text-marino">¿Todo correcto?</p>
          <BotonesDecision si="Sí, correcta" no="No, devolver al asistente" />
        </>
      );
    default:
      return null;
  }
}

const DECISIONES = new Set(["confirmar_sede", "personalizar", "dinamicas", "revisar_ficha"]);
const BOTON: Record<string, string> = {
  confirmar_local: "Solicitar confirmación",
  asignar_personal: "Asignar personal",
  comunicar: "Registrar comunicación",
  descargar_material: "Material descargado",
  examen: "Examen impreso",
  guardar_material: "Registrar",
  coordinar_salida_cap: "Registrar coordinación",
  coordinar_salida_asis: "Registrar coordinación",
  imprimir_ficha: "Impresión realizada",
  alistar_material: "Material alistado",
  probar_equipos: "Registrar prueba",
  solicitar_viaticos: "Solicitar viáticos",
  entregar_viaticos: "Registrar entrega",
  recibir_viaticos: "Confirmar recepción",
  llenar_ficha: "Ficha llenada y comunicada",
  aprobar_ficha: "Aprobar ficha",
  lista: "✓ Sesión lista, sale a sede",
};

function Tarjeta({ s, n, e, est }: { s: EstadoItem; n: number; e: Exp; est: Map<string, string> }) {
  const reg = e.ctx.pasos[s.clave];
  const icono = { hecho: "✓", disponible: String(n), bloqueado: String(n), no_aplica: "–" }[s.estado];
  const circulo = {
    hecho: "bg-[#16a34a] text-white",
    disponible: "bg-acento text-white",
    bloqueado: "bg-[#e6ebf1] text-texto-2",
    no_aplica: "bg-[#e6ebf1] text-texto-2",
  }[s.estado];
  const faltan = s.requiere.filter((r) => !["hecho", "no_aplica"].includes(est.get(r) ?? "")).map((r) => PASO[r].titulo);

  return (
    <li
      className={`card flex gap-3 p-4 ${s.estado === "disponible" ? "border-acento shadow-sm" : ""} ${s.estado === "bloqueado" || s.estado === "no_aplica" ? "opacity-70" : ""}`}
      aria-label={`${s.titulo}: ${s.estado.replace("_", " ")}`}
    >
      <span className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${circulo}`} aria-hidden="true">{icono}</span>
      <div className="flex min-w-0 flex-1 flex-col gap-1.5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <h3 className="text-sm font-semibold text-marino">{s.titulo}</h3>
          <ChipRol rol={s.rolActual} />
        </div>
        <p className="text-xs text-texto-2">{s.descripcion}</p>
        {s.nota && <p className="text-xs italic text-[#6b7280]">📝 {s.nota}</p>}

        {s.estado === "hecho" && reg && (
          <div className="flex items-start justify-between gap-2">
            <Resumen clave={s.clave} r={reg} />
            <form action={deshacerPaso}>
              <input type="hidden" name="programacionId" value={e.p.id} />
              <input type="hidden" name="clave" value={s.clave} />
              <button className="text-xs text-texto-2 underline hover:text-[#991b1b]" title="Deshacer (solo si nada posterior depende de esto)">Deshacer</button>
            </form>
          </div>
        )}
        {s.estado === "disponible" && (
          <FormPaso programacionId={e.p.id} clave={s.clave} personas={personasDe(s.rolActual, e)} boton={DECISIONES.has(s.clave) ? "" : BOTON[s.clave] ?? "Registrar"}>
            <Campos clave={s.clave} e={e} />
          </FormPaso>
        )}
        {s.estado === "bloqueado" && faltan.length > 0 && <p className="text-xs text-texto-2">Espera: {faltan.join(" · ")}</p>}
        {s.estado === "no_aplica" && <p className="text-xs text-texto-2">No aplica: no es la primera ni la última sesión de la capacitación.</p>}
      </div>
    </li>
  );
}

export default async function Expediente({ params }: PageProps<"/operativo/pre-capacitacion/[id]">) {
  await connection();
  const e = await cargarExpediente(Number((await params).id));
  if (!e) notFound();
  const { p } = e;
  const r = resumenFlujo(e.ctx);
  const num = new Map(r.estados.map((s, i) => [s.clave, i + 1]));
  const est = new Map<string, string>(r.estados.map((s) => [s.clave, s.estado]));
  const deFase = (f: number, carril?: string) => r.estados.filter((s) => s.fase === f && (!carril || s.carril === carril));
  const lista = (items: EstadoItem[]) => (
    <ol className="flex flex-col gap-3">
      {items.map((s) => <Tarjeta key={s.clave} s={s} n={num.get(s.clave)!} e={e} est={est} />)}
    </ol>
  );
  const porCat = Object.entries(CATEGORIAS).map(([k, t]) => ({ k, t, items: e.items.filter((i) => i.categoria === k) }));

  return (
    <>
      <Encabezado
        antetitulo={<><Link href="/operativo/pre-capacitacion" className="hover:underline">Pre-capacitación</Link> › Expediente de la sesión</>}
        titulo={[p.sesion.nombre, ...combinadas(p)].join(" + ")}
        acciones={
          <>
            <Link href={`/operativo/pre-capacitacion/${p.id}/ficha`} className="btn-secundario">Imprimir ficha</Link>
            <Link href={`/estrategico/cronograma/${p.id}`} className="btn-secundario">Editar programación</Link>
          </>
        }
      />

      <section className="card grid grid-cols-2 gap-4 p-5 md:grid-cols-3 xl:grid-cols-6">
        {[
          ["Fecha", fechaLarga(p.fecha), `${hora(p.horaInicio)} – ${hora(p.horaFin)}`],
          ["Capacitación", ruta(p), `${p.sesion.codigo}${p.observacion ? ` · ${p.observacion}` : ""}`],
          ["Sede", p.sede.nombre, `${p.aula ?? "Sin aula"} · ${p.sede.fueraDeArequipa ? "fuera de Arequipa" : "dentro de Arequipa"}`],
          ["Capacitador", nombreCompleto(p.capacitador), p.capacitador?.especialidad ?? ""],
          ["Asistente", nombreCompleto(p.asistente), `${e.inscritos} inscritos`],
        ].map(([t, v, d]) => (
          <div key={t} className="flex flex-col gap-0.5">
            <span className="text-xs text-texto-2">{t}</span>
            <span className="text-sm font-semibold">{v}</span>
            <span className="text-xs text-texto-2">{d}</span>
          </div>
        ))}
        <div className="col-span-2 flex flex-col justify-center gap-2 md:col-span-3 xl:col-span-1">
          <ChipEstado estado={p.estado} sinCapacitador={!p.capacitador} />
          <BarraAvance porcentaje={r.porcentaje} etiqueta="Avance del flujo" />
          <span className="text-xs text-texto-2">{r.hechos} de {r.total} actividades</span>
        </div>
      </section>

      {(p.sesion.contenido || p.sesion.recursoMetodologico || p.sesion.perfilSalida || p.sesion.objetivo) && (
        <details className="card px-5 py-4" open={r.hechos === 0}>
          <summary className="cursor-pointer text-sm font-semibold text-marino">Contenido de la sesión · {p.sesion.codigo}</summary>
          {p.sesion.objetivo && <p className="mt-3 text-sm">{p.sesion.objetivo}</p>}
          <div className="mt-3 grid grid-cols-1 gap-5 text-sm md:grid-cols-3">
            {[
              ["Contenido", p.sesion.contenido],
              ["Recurso metodológico", p.sesion.recursoMetodologico],
            ].map(([t, v]) => (
              <div key={t}>
                <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-texto-2">{t}</h3>
                {v ? (
                  <ul className="list-disc space-y-0.5 pl-4">{v.split("\n").map((l, i) => <li key={i}>{l}</li>)}</ul>
                ) : <p className="text-texto-2">—</p>}
              </div>
            ))}
            <div>
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-texto-2">Perfil de salida</h3>
              <p>{p.sesion.perfilSalida ?? "—"}</p>
            </div>
          </div>
        </details>
      )}

      {r.reprogramada && (
        <p role="alert" className="rounded-lg border border-[#fecaca] bg-[#fef2f2] px-4 py-3 text-sm text-[#991b1b]">
          <strong>Fin del flujo: Reprogramar sesión.</strong> El local no fue confirmado. Cambia la fecha en{" "}
          <Link href={`/estrategico/cronograma/${p.id}`} className="underline">Editar programación</Link> y luego usa «Deshacer» en «Confirmar con la sede» para reiniciar.
        </p>
      )}
      {r.terminado && (
        <p role="status" className="rounded-lg border border-[#bbf7d0] bg-[#f0fdf4] px-4 py-3 text-sm font-semibold text-[#166534]">
          ✓ Sesión lista: el equipo sale a sede.
        </p>
      )}

      <section id="ficha" className="card">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-borde px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold text-marino">Ficha de capacitación · 1ra sección</h2>
            <p className="text-xs text-texto-2">
              Material del capacitador, dinámicas, refrigerio y tecnológicos. Los ítems «Inventario» se descuentan del stock de Logística (y vuelven si se quitan); los «Extra» se compran aparte.
            </p>
          </div>
          <Link href={`/operativo/pre-capacitacion/${p.id}/ficha`} className="enlace text-sm">🖨 Imprimir ficha</Link>
        </div>
        <div className="grid grid-cols-1 gap-x-8 gap-y-4 px-5 py-4 md:grid-cols-2">
          {porCat.map(({ k, t, items }) => (
            <div key={k}>
              <h3 className="mb-1.5 text-[13px] font-semibold text-marino">{t}</h3>
              {items.length === 0 ? (
                <p className="text-xs text-texto-2">Sin ítems.</p>
              ) : (
                <ul className="flex flex-col gap-1">
                  {items.map((i) => (
                    <li key={i.id} className="flex items-center gap-2 text-sm">
                      <form action={alternarItem}>
                        <input type="hidden" name="itemId" value={i.id} />
                        <button
                          aria-label={`${i.listo ? "Desmarcar" : "Marcar como listo"}: ${i.descripcion}`}
                          aria-pressed={i.listo}
                          className={`flex size-5 items-center justify-center rounded border text-xs ${i.listo ? "border-[#16a34a] bg-[#16a34a] text-white" : "border-borde-fuerte bg-white"}`}
                        >
                          {i.listo ? "✓" : ""}
                        </button>
                      </form>
                      <span className={`flex-1 ${i.listo ? "text-texto-2 line-through" : ""}`}>{i.cantidad} × {i.descripcion}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${i.insumoId ? "bg-[#e0e7ff] text-[#3730a3]" : "bg-[#fef3c7] text-[#92400e]"}`}>
                        {i.insumoId ? "Inventario" : "Extra"}
                      </span>
                      <form action={eliminarItem}>
                        <input type="hidden" name="itemId" value={i.id} />
                        <button aria-label={`Quitar ${i.descripcion}`} className="text-xs text-texto-2 hover:text-[#991b1b]">Quitar</button>
                      </form>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
        <FormItem programacionId={p.id} inventario={e.inventario.map((i) => ({ id: i.id, nombre: i.nombre, stock: i.stock, unidad: i.unidad, categoria: i.categoria }))} />
      </section>

      {[1, 2].map((f) => (
        <section key={f} className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold text-marino">Fase {f} · {FASES[f as 1 | 2]}</h2>
          {lista(deFase(f))}
        </section>
      ))}

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold text-marino">Fase 3 · {FASES[3]} <span className="text-sm font-normal text-texto-2">(en paralelo)</span></h2>
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
          <div className="flex flex-col gap-3">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-[#9a3412]">Capacitador</h3>
            {lista(deFase(3, "capacitador"))}
          </div>
          <div className="flex flex-col gap-3">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-[#115e59]">Asistente y áreas de apoyo</h3>
            {lista(deFase(3, "asistente"))}
          </div>
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold text-marino">Fase 4 · {FASES[4]}</h2>
        {lista(deFase(4))}
      </section>
    </>
  );
}
