"use server";

import { and, eq, gt, inArray, lt, ne, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import {
  capacitadores,
  fichaItems,
  insumos,
  personal,
  preparaciones,
  programaciones,
  type CategoriaFicha,
  type PasoRegistro,
} from "@/db/schema";
import { DIAS_ANTICIPACION_COMUNICACION, PASO, PASOS, estadoPaso } from "@/lib/flujo-pre";
import { contexto, examenDe, examenes } from "@/lib/preparacion";
import { fechaCorta, sumarDias } from "@/lib/fechas";
import { moverStock } from "@/lib/stock";

export type Res = { ok?: string; error?: string } | undefined;

const txt = (f: FormData, k: string) => String(f.get(k) ?? "").trim();
const nombre = (x: { nombres: string; apellidos: string } | undefined | null) => (x ? `${x.nombres} ${x.apellidos}`.trim() : null);

async function cargar(id: number) {
  const p = await db.query.programaciones.findFirst({
    where: eq(programaciones.id, id),
    with: { sede: true, preparacion: true, sesion: true, combinadas: true },
  });
  if (!p) return null;
  const ex = await examenes([p.sesionId, ...p.combinadas.map((c) => c.sesionId)]);
  return { p, ctx: contexto(p.preparacion?.pasos, p.sede.fueraDeArequipa, examenDe(p, ex)) };
}

async function guardarPasos(programacionId: number, pasos: Record<string, PasoRegistro>) {
  await db
    .insert(preparaciones)
    .values({ programacionId, pasos })
    .onConflictDoUpdate({ target: preparaciones.programacionId, set: { pasos, actualizadoEn: sql`now()` } });
}

function refrescar(id: number) {
  revalidatePath(`/operativo/pre-capacitacion/${id}`);
  revalidatePath("/", "layout");
}

/** Error de stock: se lanza dentro de la transacción para deshacerla. */
class SinStock extends Error {}

async function motivoDe(id: number) {
  const p = await db.query.programaciones.findFirst({ where: eq(programaciones.id, id), with: { sesion: true, sede: true } });
  return p ? `Ficha ${p.sesion.codigo} · ${p.sede.nombre} · ${fechaCorta(p.fecha)}` : `Ficha de sesión #${id}`;
}

/** Cantidades pedidas del inventario: campos «inv-<id>» del formulario. */
function lineasInventario(f: FormData) {
  return [...f.entries()]
    .filter(([k]) => k.startsWith("inv-"))
    .map(([k, v]) => ({ insumoId: Number(k.slice(4)), cantidad: Math.floor(Number(v)) }))
    .filter((l) => l.insumoId > 0 && l.cantidad > 0);
}

/** Registra (completa) una actividad del flujo. */
export async function registrarPaso(_prev: Res, f: FormData): Promise<Res> {
  const id = Number(f.get("programacionId"));
  const clave = txt(f, "clave");
  const por = txt(f, "por") || null;
  const def = PASO[clave];
  if (!def) return { error: "Actividad no válida." };

  const x = await cargar(id);
  if (!x) return { error: "La sesión ya no existe." };
  const { p, ctx } = x;
  const estado = estadoPaso(clave, ctx);
  if (estado === "hecho") return { error: "Esta actividad ya fue registrada." };
  if (estado !== "disponible") return { error: "Primero deben completarse las actividades anteriores." };

  const pasos = { ...ctx.pasos };
  const reg: PasoRegistro = { en: new Date().toISOString(), por };
  const decision = txt(f, "decision");
  const siNo = decision === "si" ? true : decision === "no" ? false : null;

  switch (clave) {
    case "confirmar_local":
      reg.obs = txt(f, "obs") || null;
      break;

    case "confirmar_sede": {
      if (siNo === null) return { error: "Indica si el local quedó confirmado." };
      reg.localConfirmado = siNo;
      reg.contacto = txt(f, "contacto") || null;
      reg.obs = txt(f, "obs") || null;
      if (!siNo && !reg.obs) return { error: "Indica el motivo por el que no se confirmó el local." };
      if (!siNo) await db.update(programaciones).set({ estado: "reprogramada" }).where(eq(programaciones.id, id));
      break;
    }

    case "asignar_personal": {
      const capId = Number(f.get("capacitadorId")) || null;
      const asiId = Number(f.get("asistenteId")) || null;
      if (!capId || !asiId) return { error: "Asigna capacitador y asistente. Si no hay disponibilidad, revisa otras personas o reprograma." };
      const cruce = (col: typeof programaciones.capacitadorId | typeof programaciones.asistenteId, valor: number) =>
        db.query.programaciones.findFirst({
          where: and(
            eq(col, valor),
            eq(programaciones.fecha, p.fecha),
            lt(programaciones.horaInicio, p.horaFin),
            gt(programaciones.horaFin, p.horaInicio),
            ne(programaciones.estado, "cancelada"),
            ne(programaciones.id, id),
          ),
          with: { sede: true },
        });
      const [c1, c2, cap, asi] = await Promise.all([
        cruce(programaciones.capacitadorId, capId),
        cruce(programaciones.asistenteId, asiId),
        db.query.capacitadores.findFirst({ where: eq(capacitadores.id, capId) }),
        db.query.personal.findFirst({ where: eq(personal.id, asiId) }),
      ]);
      if (c1) return { error: `Sin disponibilidad: el capacitador ya tiene sesión de ${c1.horaInicio.slice(0, 5)} a ${c1.horaFin.slice(0, 5)} en ${c1.sede.nombre}.` };
      if (c2) return { error: `Sin disponibilidad: el asistente ya tiene sesión de ${c2.horaInicio.slice(0, 5)} a ${c2.horaFin.slice(0, 5)} en ${c2.sede.nombre}.` };
      await db.update(programaciones).set({ capacitadorId: capId, asistenteId: asiId }).where(eq(programaciones.id, id));
      reg.capacitador = nombre(cap);
      reg.asistente = nombre(asi);
      break;
    }

    case "comunicar": {
      const limite = sumarDias(p.fecha, -DIAS_ANTICIPACION_COMUNICACION);
      reg.limite = limite;
      reg.aTiempo = reg.en.slice(0, 10) <= limite;
      reg.obs = txt(f, "obs") || null;
      break;
    }

    case "personalizar":
      if (siNo === null) return { error: "Indica si se personalizó el contenido." };
      reg.personalizado = siNo;
      reg.detalle = txt(f, "detalle") || null;
      if (siNo && !reg.detalle) return { error: "Describe qué se personalizó." };
      break;

    case "dinamicas": {
      if (siNo === null) return { error: "Indica si se requiere material para dinámicas." };
      reg.requiere = siNo;
      if (siNo) {
        const delInventario = lineasInventario(f);
        const extras = txt(f, "items").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
          const m = l.match(/^(\d+)\s*[x×]?\s+(.+)$/i);
          return { programacionId: id, categoria: "dinamica" as CategoriaFicha, cantidad: m ? Number(m[1]) : 1, descripcion: (m ? m[2] : l).slice(0, 200) };
        });
        if (!delInventario.length && !extras.length) return { error: "Indica el material: cantidades del inventario y/o extras (uno por línea)." };
        const nombres = delInventario.length
          ? new Map((await db.select().from(insumos).where(inArray(insumos.id, delInventario.map((l) => l.insumoId)))).map((i) => [i.id, i.nombre]))
          : new Map<number, string>();
        const motivo = await motivoDe(id);
        try {
          await db.transaction(async (tx) => {
            const err = await moverStock(tx, "salida", delInventario, id, `${motivo} · dinámicas`);
            if (err) throw new SinStock(err);
            const valores = [
              ...delInventario.map((l) => ({
                programacionId: id,
                categoria: "dinamica" as CategoriaFicha,
                cantidad: l.cantidad,
                insumoId: l.insumoId,
                descripcion: nombres.get(l.insumoId) ?? "Material",
              })),
              ...extras,
            ];
            await tx.insert(fichaItems).values(valores);
          });
        } catch (e) {
          if (e instanceof SinStock) return { error: e.message };
          throw e;
        }
        reg.items = delInventario.length + extras.length;
        reg.delInventario = delInventario.length;
        reg.extras = extras.length;
      }
      break;
    }

    case "examen":
      reg.tipo = ctx.examen;
      reg.cantidad = Number(f.get("cantidad")) || null;
      break;

    case "guardar_material":
      reg.medio = txt(f, "medio");
      if (!reg.medio) return { error: "Indica el medio seguro donde se guardó el material." };
      reg.talleresImpresos = f.get("talleresImpresos") === "on";
      break;

    case "coordinar_salida_cap":
    case "coordinar_salida_asis":
      reg.horaSalida = txt(f, "horaSalida");
      reg.punto = txt(f, "punto") || null;
      if (!reg.horaSalida) return { error: "Indica la hora de salida." };
      break;

    case "alistar_material": {
      const [{ pendientes }] = await db
        .select({ pendientes: sql<number>`count(*) filter (where not ${fichaItems.listo})::int` })
        .from(fichaItems)
        .where(eq(fichaItems.programacionId, id));
      if (pendientes > 0) return { error: `Faltan ${pendientes} ítems de la ficha por marcar como listos.` };
      break;
    }

    case "probar_equipos":
      reg.resultado = txt(f, "resultado") || "ok";
      reg.obs = txt(f, "obs") || null;
      if (reg.resultado === "observado" && !reg.obs) return { error: "Describe qué equipo falló o qué se observó." };
      break;

    case "solicitar_viaticos": {
      const monto = Number(f.get("monto"));
      if (!(monto > 0)) return { error: "Indica el monto solicitado." };
      reg.monto = monto;
      reg.concepto = txt(f, "concepto") || null;
      break;
    }

    case "entregar_viaticos": {
      const monto = Number(f.get("monto"));
      if (!(monto > 0)) return { error: "Indica el monto entregado." };
      reg.monto = monto;
      reg.tipo = ctx.fueraDeArequipa ? "viaje" : "movilidad";
      break;
    }

    case "revisar_ficha": {
      if (siNo === null) return { error: "Indica si la ficha está correcta." };
      if (!siNo) {
        const obs = txt(f, "obs");
        if (!obs) return { error: "Escribe las observaciones para el asistente." };
        // Vuelve al asistente: se reabre "llenar ficha"
        delete pasos.llenar_ficha;
        const historial = Array.isArray(pasos.observaciones_ficha?.lista) ? (pasos.observaciones_ficha.lista as unknown[]) : [];
        pasos.observaciones_ficha = { en: reg.en, por, lista: [...historial, { en: reg.en, por, obs }] };
        await guardarPasos(id, pasos);
        refrescar(id);
        return { ok: "Ficha devuelta al asistente con observaciones." };
      }
      reg.correcto = true;
      break;
    }

    case "lista":
      if (p.estado !== "cancelada") {
        await db.update(programaciones).set({ estado: "confirmada" }).where(eq(programaciones.id, id));
      }
      break;

    default:
      reg.obs = txt(f, "obs") || null;
  }

  pasos[clave] = reg;
  await guardarPasos(id, pasos);
  refrescar(id);
  return { ok: `✓ ${def.titulo}` };
}

/** Deshace una actividad registrada por error (solo si ninguna actividad posterior depende de ella). */
export async function deshacerPaso(f: FormData) {
  const id = Number(f.get("programacionId"));
  const clave = txt(f, "clave");
  const x = await cargar(id);
  if (!x || !PASO[clave]) return;
  const dependientes = PASOS.filter((d) => d.requiere.includes(clave) && x.ctx.pasos[d.clave]);
  if (dependientes.length) return;

  const pasos = { ...x.ctx.pasos };
  const previo = pasos[clave];
  delete pasos[clave];
  if (clave === "confirmar_sede" && previo?.localConfirmado === false) {
    await db.update(programaciones).set({ estado: "programada" }).where(eq(programaciones.id, id));
  }
  if (clave === "dinamicas") {
    const motivo = `Devolución · ${await motivoDe(id)} · se deshizo «dinámicas»`;
    await db.transaction(async (tx) => {
      const borrados = await tx
        .delete(fichaItems)
        .where(and(eq(fichaItems.programacionId, id), eq(fichaItems.categoria, "dinamica")))
        .returning();
      const lineas = borrados.filter((b) => b.insumoId).map((b) => ({ insumoId: b.insumoId!, cantidad: b.cantidad }));
      await moverStock(tx, "entrada", lineas, id, motivo);
    });
  }
  await guardarPasos(id, pasos);
  refrescar(id);
}

/* ── 1ra sección de la ficha ─────────────────────────────── */

export async function agregarItem(_prev: Res, f: FormData): Promise<Res> {
  const id = Number(f.get("programacionId"));
  const insumoId = Number(f.get("insumoId")) || null;
  const categoria = txt(f, "categoria") as CategoriaFicha;
  const cantidad = Math.max(1, Math.floor(Number(f.get("cantidad"))) || 1);
  let descripcion = txt(f, "descripcion");
  if (!["material_capacitador", "dinamica", "refrigerio", "tecnologico"].includes(categoria)) return { error: "Categoría no válida." };

  if (!insumoId) {
    if (!descripcion) return { error: "Escribe el ítem o elígelo del inventario." };
    await db.insert(fichaItems).values({ programacionId: id, categoria, descripcion: descripcion.slice(0, 200), cantidad });
    refrescar(id);
    return { ok: "Ítem extra agregado." };
  }

  const motivo = await motivoDe(id);
  try {
    await db.transaction(async (tx) => {
      const [i] = await tx.select().from(insumos).where(eq(insumos.id, insumoId));
      if (!i) throw new SinStock("Ese ítem ya no está en el inventario.");
      const err = await moverStock(tx, "salida", [{ insumoId, cantidad }], id, motivo);
      if (err) throw new SinStock(err);
      descripcion = descripcion ? `${i.nombre} · ${descripcion}` : i.nombre;
      await tx.insert(fichaItems).values({ programacionId: id, categoria, descripcion: descripcion.slice(0, 200), cantidad, insumoId });
    });
  } catch (e) {
    if (e instanceof SinStock) return { error: e.message };
    throw e;
  }
  refrescar(id);
  revalidatePath("/soporte/logistica");
  return { ok: `Descontado del inventario: ${cantidad} × ${descripcion}.` };
}

export async function alternarItem(f: FormData) {
  const itemId = Number(f.get("itemId"));
  const [it] = await db
    .update(fichaItems)
    .set({ listo: sql`not ${fichaItems.listo}` })
    .where(eq(fichaItems.id, itemId))
    .returning();
  if (it) refrescar(it.programacionId);
}

export async function eliminarItem(f: FormData) {
  const itemId = Number(f.get("itemId"));
  const it = await db.transaction(async (tx) => {
    const [b] = await tx.delete(fichaItems).where(eq(fichaItems.id, itemId)).returning();
    if (b?.insumoId) {
      // Vuelve al inventario lo que se había descontado
      await moverStock(tx, "entrada", [{ insumoId: b.insumoId, cantidad: b.cantidad }], b.programacionId, `Devolución · quitado de la ficha (${b.descripcion})`);
    }
    return b;
  });
  if (it) refrescar(it.programacionId);
}
