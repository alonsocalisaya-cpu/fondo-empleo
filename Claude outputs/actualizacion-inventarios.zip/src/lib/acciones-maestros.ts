"use server";

import { eq, not } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { capacitadores, documentos, equipos, participantes, personal, sedes } from "@/db/schema";

export type Res = { ok?: string; error?: string } | undefined;
const txt = (f: FormData, k: string) => String(f.get(k) ?? "").trim() || null;
const duplicado = (e: unknown) => (e as { cause?: { code?: string } })?.cause?.code === "23505";

export async function crearSede(_p: Res, f: FormData): Promise<Res> {
  const nombre = txt(f, "nombre");
  if (!nombre) return { error: "El nombre es obligatorio." };
  try {
    await db.insert(sedes).values({
      nombre,
      direccion: txt(f, "direccion"),
      distrito: txt(f, "distrito"),
      fueraDeArequipa: txt(f, "ubicacion") === "fuera",
      contacto: txt(f, "contacto"),
      telefono: txt(f, "telefono"),
    });
  } catch (e) {
    return { error: duplicado(e) ? "Ya existe una sede con ese nombre." : "No se pudo guardar." };
  }
  revalidatePath("/", "layout");
  return { ok: `Sede «${nombre}» creada.` };
}

export async function alternarSede(f: FormData) {
  await db.update(sedes).set({ activa: not(sedes.activa) }).where(eq(sedes.id, Number(f.get("id"))));
  revalidatePath("/", "layout");
}

export async function crearCapacitador(_p: Res, f: FormData): Promise<Res> {
  const nombres = txt(f, "nombres");
  const apellidos = txt(f, "apellidos");
  if (!nombres || !apellidos) return { error: "Nombres y apellidos son obligatorios." };
  try {
    await db.insert(capacitadores).values({
      nombres,
      apellidos,
      dni: txt(f, "dni"),
      email: txt(f, "email"),
      telefono: txt(f, "telefono"),
      especialidad: txt(f, "especialidad"),
    });
  } catch (e) {
    return { error: duplicado(e) ? "Ya existe un consultor con ese DNI." : "No se pudo guardar." };
  }
  revalidatePath("/", "layout");
  return { ok: `Consultor ${nombres} ${apellidos} registrado.` };
}

export async function alternarCapacitador(f: FormData) {
  await db
    .update(capacitadores)
    .set({ activo: not(capacitadores.activo) })
    .where(eq(capacitadores.id, Number(f.get("id"))));
  revalidatePath("/", "layout");
}

export async function crearParticipante(_p: Res, f: FormData): Promise<Res> {
  const nombres = txt(f, "nombres");
  const apellidos = txt(f, "apellidos");
  const dni = txt(f, "dni");
  if (!nombres || !apellidos || !dni) return { error: "Nombres, apellidos y DNI son obligatorios." };
  if (!/^\d{8,12}$/.test(dni)) return { error: "El DNI debe tener solo números (8 a 12 dígitos)." };
  try {
    await db.insert(participantes).values({
      nombres,
      apellidos,
      dni,
      email: txt(f, "email"),
      telefono: txt(f, "telefono"),
      area: txt(f, "area"),
    });
  } catch (e) {
    return { error: duplicado(e) ? "Ya existe un participante con ese DNI." : "No se pudo guardar." };
  }
  revalidatePath("/operativo/pre-capacitacion/participantes");
  return { ok: `Participante ${nombres} ${apellidos} registrado.` };
}

/* ── Personal interno ─────────────────────────────────────── */
const ROLES_VALIDOS = ["jefe_comercial", "jefe_proyecto", "asistente", "gestion_documental", "administradora", "rrhh"] as const;

export async function crearPersonal(_p: Res, f: FormData): Promise<Res> {
  const nombres = txt(f, "nombres");
  const apellidos = txt(f, "apellidos");
  const rol = txt(f, "rol") as (typeof ROLES_VALIDOS)[number];
  if (!nombres || !apellidos) return { error: "Nombres y apellidos son obligatorios." };
  if (!ROLES_VALIDOS.includes(rol)) return { error: "Elige un rol." };
  try {
    await db.insert(personal).values({ nombres, apellidos, rol, dni: txt(f, "dni"), email: txt(f, "email"), telefono: txt(f, "telefono") });
  } catch (e) {
    return { error: duplicado(e) ? "Ya existe una persona con ese DNI." : "No se pudo guardar." };
  }
  revalidatePath("/", "layout");
  return { ok: `${nombres} ${apellidos} registrado.` };
}

export async function alternarPersonal(f: FormData) {
  await db.update(personal).set({ activo: not(personal.activo) }).where(eq(personal.id, Number(f.get("id"))));
  revalidatePath("/", "layout");
}

/* ── Gestión documental ───────────────────────────────────── */
const TIPOS_DOC = ["diapositiva", "taller", "examen_entrada", "examen_salida", "ficha", "otro"] as const;

export async function crearDocumento(_p: Res, f: FormData): Promise<Res> {
  const nombre = txt(f, "nombre");
  const url = txt(f, "url");
  const tipo = txt(f, "tipo") as (typeof TIPOS_DOC)[number];
  const sesionId = Number(f.get("sesionId")) || null;
  if (!nombre || !url) return { error: "Nombre y enlace son obligatorios." };
  if (!/^https?:\/\//i.test(url)) return { error: "El enlace debe empezar con http:// o https://" };
  if (!TIPOS_DOC.includes(tipo)) return { error: "Elige el tipo de documento." };
  await db.insert(documentos).values({ nombre, url, tipo, sesionId, version: txt(f, "version") });
  revalidatePath("/", "layout");
  return { ok: `Documento «${nombre}» agregado al repositorio.` };
}

export async function eliminarDocumento(f: FormData) {
  await db.delete(documentos).where(eq(documentos.id, Number(f.get("id"))));
  revalidatePath("/", "layout");
}

/* ── Mantenimiento: equipos ───────────────────────────────── */
export async function cambiarEstadoEquipo(f: FormData) {
  const estado = txt(f, "estado") as "operativo" | "en_reparacion" | "de_baja";
  if (!["operativo", "en_reparacion", "de_baja"].includes(estado)) return;
  await db
    .update(equipos)
    .set({ estado, observacion: txt(f, "observacion") })
    .where(eq(equipos.id, Number(f.get("id"))));
  revalidatePath("/", "layout");
}
