import type { CategoriaInsumo, TipoEquipo } from "@/db/schema";

/** Etiquetas del inventario de equipos (Mantenimiento). */
export const TIPOS_EQUIPO: Record<TipoEquipo, { singular: string; plural: string; prefijo: string }> = {
  laptop: { singular: "Laptop", plural: "Laptops", prefijo: "LAP" },
  proyector: { singular: "Proyector", plural: "Proyectores", prefijo: "PRY" },
  cable_hdmi: { singular: "Cable HDMI", plural: "Cables HDMI", prefijo: "HDMI" },
  extension: { singular: "Extensión", plural: "Extensiones", prefijo: "EXT" },
  cargador_laptop: { singular: "Cargador de laptop", plural: "Cargadores de laptop", prefijo: "CAR" },
  enchufe_proyector: { singular: "Enchufe del proyector", plural: "Enchufes del proyector", prefijo: "ENP" },
  mochila: { singular: "Mochila", plural: "Mochilas", prefijo: "MOC" },
  otro: { singular: "Otro", plural: "Otros", prefijo: "OTR" },
};

/** Categorías del inventario de materiales (Logística). */
export const CATEGORIAS_INSUMO: Record<CategoriaInsumo, string> = {
  material: "Material de capacitación",
  refrigerio: "Refrigerio",
};
