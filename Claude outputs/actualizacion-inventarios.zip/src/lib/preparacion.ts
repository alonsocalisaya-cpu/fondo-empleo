import "server-only";
import { and, asc, eq, gt, inArray, isNull, lt, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  actividades,
  documentos,
  equipos,
  fichaItems,
  inscripciones,
  insumos,
  modulos,
  preparaciones,
  programaciones,
  sesiones,
  type PasoRegistro,
} from "@/db/schema";
import { conRuta } from "./consultas";
import type { ContextoFlujo } from "./flujo-pre";

/**
 * Para cada sesión, ¿es la primera o la última de su capacitación (actividad)?
 * Primera → examen de entrada; última → examen de salida; si la actividad tiene una sola sesión → ambos.
 */
export async function examenes(sesionIds: number[]) {
  const res = new Map<number, ContextoFlujo["examen"]>();
  if (!sesionIds.length) return res;
  const acts = await db
    .selectDistinct({ id: modulos.actividadId })
    .from(sesiones)
    .innerJoin(modulos, eq(sesiones.moduloId, modulos.id))
    .where(inArray(sesiones.id, sesionIds));
  const filas = await db
    .select({ sesionId: sesiones.id, actividadId: modulos.actividadId })
    .from(sesiones)
    .innerJoin(modulos, eq(sesiones.moduloId, modulos.id))
    .innerJoin(actividades, eq(modulos.actividadId, actividades.id))
    .where(inArray(modulos.actividadId, acts.map((a) => a.id)))
    .orderBy(asc(modulos.actividadId), asc(modulos.orden), asc(modulos.id), asc(sesiones.orden), asc(sesiones.id));

  const porActividad = new Map<number, number[]>();
  for (const f of filas) porActividad.set(f.actividadId, [...(porActividad.get(f.actividadId) ?? []), f.sesionId]);
  for (const lista of porActividad.values()) {
    lista.forEach((id, i) => {
      const primera = i === 0;
      const ultima = i === lista.length - 1;
      res.set(id, primera && ultima ? "ambos" : primera ? "entrada" : ultima ? "salida" : null);
    });
  }
  return res;
}

type ProgSesiones = { sesionId: number; combinadas?: { sesionId: number }[] };
const idsSesiones = (p: ProgSesiones) => [p.sesionId, ...(p.combinadas ?? []).map((c) => c.sesionId)];

/** Examen que corresponde a una programación, considerando también sus sesiones combinadas. */
export function examenDe(p: ProgSesiones, ex: Map<number, ContextoFlujo["examen"]>): ContextoFlujo["examen"] {
  const tipos = idsSesiones(p).map((id) => ex.get(id) ?? null);
  const entrada = tipos.some((t) => t === "entrada" || t === "ambos");
  const salida = tipos.some((t) => t === "salida" || t === "ambos");
  return entrada && salida ? "ambos" : entrada ? "entrada" : salida ? "salida" : null;
}

export function contexto(
  pasos: Record<string, PasoRegistro> | undefined,
  fueraDeArequipa: boolean,
  examen: ContextoFlujo["examen"],
): ContextoFlujo {
  return { pasos: pasos ?? {}, fueraDeArequipa, examen };
}

/** Todo lo necesario para la página del expediente de pre-capacitación de una sesión. */
export async function cargarExpediente(id: number) {
  const p = await db.query.programaciones.findFirst({
    where: eq(programaciones.id, id),
    with: { ...conRuta, asistente: true, preparacion: true },
  });
  if (!p) return null;

  const [items, docs, eqs, [{ inscritos }], ex, personal, consultores, inventario] = await Promise.all([
    db.select().from(fichaItems).where(eq(fichaItems.programacionId, id)).orderBy(fichaItems.categoria, fichaItems.id),
    db.select().from(documentos).where(inArray(documentos.sesionId, idsSesiones(p))).orderBy(documentos.tipo, documentos.nombre),
    db.query.equipos.findMany({
      where: or(eq(equipos.sedeId, p.sedeId), isNull(equipos.sedeId)),
      with: { sede: true },
      orderBy: (t) => t.nombre,
    }),
    db.select({ inscritos: sql<number>`count(*)::int` }).from(inscripciones).where(eq(inscripciones.programacionId, id)),
    examenes(idsSesiones(p)),
    db.query.personal.findMany({ where: (t, { eq }) => eq(t.activo, true), orderBy: (t) => [t.nombres, t.apellidos] }),
    db.query.capacitadores.findMany({ where: (t, { eq }) => eq(t.activo, true), orderBy: (t) => [t.nombres, t.apellidos] }),
    db.select().from(insumos).where(eq(insumos.activo, true)).orderBy(insumos.categoria, insumos.nombre),
  ]);

  // Personas ocupadas: tienen otra sesión el mismo día con horario que se cruza
  const cruces = await db.query.programaciones.findMany({
    where: and(
      eq(programaciones.fecha, p.fecha),
      lt(programaciones.horaInicio, p.horaFin),
      gt(programaciones.horaFin, p.horaInicio),
      ne(programaciones.estado, "cancelada"),
      ne(programaciones.id, id),
    ),
    with: { sede: true },
  });
  const ocupado = (quien: number | null, c: (typeof cruces)[number]) =>
    quien ? [[quien, `${c.horaInicio.slice(0, 5)}–${c.horaFin.slice(0, 5)} en ${c.sede.nombre}`] as const] : [];
  const ocupadosCap = new Map(cruces.flatMap((c) => ocupado(c.capacitadorId, c)));
  const ocupadosAsis = new Map(cruces.flatMap((c) => ocupado(c.asistenteId, c)));

  return {
    p,
    ocupadosCap,
    ocupadosAsis,
    items,
    docs,
    equipos: eqs,
    inscritos,
    personal,
    consultores,
    inventario,
    ctx: contexto(p.preparacion?.pasos, p.sede.fueraDeArequipa, examenDe(p, ex)),
  };
}

/** Estados del flujo de varias programaciones (para la bandeja). */
export async function contextosDe(progs: ({ id: number; sede: { fueraDeArequipa: boolean } } & ProgSesiones)[]) {
  const ids = progs.map((p) => p.id);
  const [preps, ex] = await Promise.all([
    ids.length ? db.select().from(preparaciones).where(inArray(preparaciones.programacionId, ids)) : Promise.resolve([]),
    examenes([...new Set(progs.flatMap(idsSesiones))]),
  ]);
  const m = new Map(preps.map((x) => [x.programacionId, x.pasos]));
  return new Map(progs.map((p) => [p.id, contexto(m.get(p.id), p.sede.fueraDeArequipa, examenDe(p, ex))]));
}
